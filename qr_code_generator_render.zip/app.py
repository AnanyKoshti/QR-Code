from flask import Flask, render_template, request, send_file
import qrcode
from PIL import Image, ImageDraw, ImageFont
import io

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        data = request.form["data"]
        text_above = request.form["text_above"]
        text_below = request.form["text_below"]

        font_path = "Roboto-Regular.ttf"
        font_size = 24

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        qr_width, qr_height = img.size

        try:
            font = ImageFont.truetype(font_path, font_size)
        except:
            font = ImageFont.load_default()

        draw_temp = ImageDraw.Draw(img)
        text_height = draw_temp.textbbox((0, 0), "Sample", font=font)[3] + 10

        new_height = qr_height + 2 * text_height
        new_img = Image.new("RGB", (qr_width, new_height), "white")
        new_img.paste(img, (0, text_height))

        draw = ImageDraw.Draw(new_img)
        draw.text(((qr_width - draw.textlength(text_above, font)) // 2, 5), text_above, fill="black", font=font)
        draw.text(((qr_width - draw.textlength(text_below, font)) // 2, qr_height + text_height + 5), text_below, fill="black", font=font)

        img_io = io.BytesIO()
        new_img.save(img_io, 'PNG')
        img_io.seek(0)

        return send_file(img_io, mimetype='image/png')

    return render_template("index.html")
