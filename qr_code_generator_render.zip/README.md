# QR Code Generator (Flask + Render)

A simple QR code generator web app with text above and below the QR. Deployed using Flask on Render.

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

## Deploy on Render

1. Push to GitHub.
2. Go to [https://render.com](https://render.com).
3. Create New > Web Service.
4. Connect GitHub repo.
5. Set:
   - **Build command**: `pip install -r requirements.txt`
   - **Start command**: `gunicorn app:app`
